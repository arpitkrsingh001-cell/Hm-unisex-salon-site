HM UNISEX SALON — PROFESSIONAL WEBSITE

IMPORTANT: Keep index.html and the images folder together. The photos are stored locally in images/ and do not rely on image-host URLs.

Preview: open index.html in a browser after extracting the ZIP.
Online hosting: upload index.html and the complete images folder to the same static hosting project. Do not upload index.html alone.
The site includes the provided salon photos, click-to-call phone link, Google Maps directions and embedded map.
